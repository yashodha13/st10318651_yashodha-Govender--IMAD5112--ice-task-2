package com.yashodha.icetask2_yashg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var guessEditText: EditText
    private lateinit var textView: TextView
    private lateinit var submitButton: Button
    private lateinit var button2 : Button
    private var randomNumber: Int = 0






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        guessEditText = findViewById(R.id.guessEditText)
        textView = findViewById(R.id.textView)
        submitButton = findViewById(R.id.submitButton)
        button2 = findViewById (R.id.button2)

        randomNumber = Random.nextInt (1,101)

        submitButton.setOnClickListener {
            val userGuess = guessEditText.text.toString().toInt()
            when {
                userGuess == 55 -> textView.text = "Correct!"
                userGuess < 101-> textView.text = "Greater Than"
                userGuess > 40 -> textView.text = "Less Than"

            }
            button2.setOnClickListener {
                textView.text=""

            }
        }

    }
}

